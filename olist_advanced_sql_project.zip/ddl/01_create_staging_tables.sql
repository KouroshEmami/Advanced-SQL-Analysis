-- Staging tables: exact copy of raw CSV structure
-- Use unlogged tables for faster bulk load
CREATE UNLOGGED TABLE IF NOT EXISTS stg_orders (
    order_id                VARCHAR PRIMARY KEY,
    customer_id             VARCHAR,
    order_status            VARCHAR,
    order_purchase_timestamp TIMESTAMP,
    order_approved_timestamp TIMESTAMP,
    order_delivered_carrier_date TIMESTAMP,
    order_delivered_customer_date TIMESTAMP,
    order_estimated_delivery_date DATE
);

-- Repeat analogously for stg_order_items, stg_customers, stg_payments, stg_products, stg_sellers, stg_reviews ...
