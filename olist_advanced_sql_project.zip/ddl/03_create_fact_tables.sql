/*==============================================================
  Fact Tables
==============================================================*/
CREATE TABLE IF NOT EXISTS fact_orders (
    order_sk          BIGSERIAL PRIMARY KEY,
    order_id          VARCHAR,
    customer_sk       INTEGER REFERENCES dim_customer(customer_sk),
    order_date_sk     INTEGER REFERENCES dim_date(date_sk),
    status            VARCHAR,
    order_item_count  SMALLINT,
    total_items_price NUMERIC,
    freight_value     NUMERIC,
    review_score      SMALLINT,
    delivery_days     INTEGER
);

CREATE TABLE IF NOT EXISTS fact_payments (
    payment_sk        BIGSERIAL PRIMARY KEY,
    order_sk          BIGINT REFERENCES fact_orders(order_sk),
    payment_type      VARCHAR,
    installments      SMALLINT,
    payment_value     NUMERIC
);
