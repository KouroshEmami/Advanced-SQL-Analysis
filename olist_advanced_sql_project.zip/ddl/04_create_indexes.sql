/*==============================================================
  Performance indexes / partitioning
==============================================================*/
-- Index customers by unique ID for fast SCD lookup
CREATE INDEX IF NOT EXISTS idx_dim_customer_unique
    ON dim_customer (customer_unique_id)
    WHERE is_current;

-- Partition fact_orders by year for pruning
ALTER TABLE fact_orders
    PARTITION BY RANGE (order_date_sk);

-- Example partition for 2017
CREATE TABLE IF NOT EXISTS fact_orders_2017 PARTITION OF fact_orders
    FOR VALUES FROM (20170101) TO (20180101);
