/*==============================================================
  Dimension Tables
==============================================================*/
CREATE TABLE IF NOT EXISTS dim_customer (
    customer_sk       SERIAL PRIMARY KEY,
    customer_unique_id VARCHAR NOT NULL,
    customer_city      VARCHAR,
    customer_state     VARCHAR,
    effective_from     DATE DEFAULT CURRENT_DATE,
    effective_to       DATE DEFAULT '9999-12-31',
    is_current         BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS dim_product (
    product_sk        SERIAL PRIMARY KEY,
    product_id        VARCHAR NOT NULL,
    product_category_name VARCHAR,
    product_photos_qty INT,
    product_weight_g   NUMERIC,
    product_length_cm  NUMERIC,
    product_height_cm  NUMERIC,
    product_width_cm   NUMERIC,
    effective_from     DATE DEFAULT CURRENT_DATE,
    effective_to       DATE DEFAULT '9999-12-31',
    is_current         BOOLEAN DEFAULT TRUE
);

-- Date dimension snippet
CREATE TABLE IF NOT EXISTS dim_date (
    date_sk           INTEGER PRIMARY KEY,
    full_date         DATE,
    day               SMALLINT,
    month             SMALLINT,
    year              SMALLINT,
    quarter           SMALLINT,
    is_weekend        BOOLEAN
);
