-- Create dedicated schema for the data warehouse
CREATE SCHEMA IF NOT EXISTS olist_dw;
SET search_path TO olist_dw;
