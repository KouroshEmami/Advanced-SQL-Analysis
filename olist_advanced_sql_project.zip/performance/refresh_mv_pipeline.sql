-- Scheduled pipeline to refresh materialized views and analyze tables
DO $$
BEGIN
    PERFORM sp_load_fact_orders();
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_monthly_kpi;
    ANALYZE fact_orders;
END $$;
