/*==============================================================
  Query Tuning Examples: before & after EXPLAIN ANALYZE
==============================================================*/
-- BEFORE: full table scan
EXPLAIN ANALYZE
SELECT * FROM fact_orders WHERE order_id = '1234';

-- AFTER: hit on PRIMARY KEY
-- (should already be fast; we can show effect of partial indexes, etc.)
