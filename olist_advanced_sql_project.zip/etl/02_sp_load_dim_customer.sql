/*==============================================================
  Stored Procedure: Incremental upsert for dim_customer (SCD‑2)
==============================================================*/
CREATE OR REPLACE PROCEDURE sp_load_dim_customer()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Close previous version
    UPDATE dim_customer dc
    SET effective_to = CURRENT_DATE - 1,
        is_current   = FALSE
    FROM stg_customers sc
    WHERE dc.customer_unique_id = sc.customer_unique_id
      AND (dc.customer_city <> sc.customer_city
           OR dc.customer_state <> sc.customer_state)
      AND dc.is_current;

    -- Insert new version for changed or new customers
    INSERT INTO dim_customer (customer_unique_id, customer_city, customer_state)
    SELECT sc.customer_unique_id, sc.customer_city, sc.customer_state
    FROM stg_customers sc
    LEFT JOIN dim_customer dc
      ON dc.customer_unique_id = sc.customer_unique_id
      AND dc.is_current
    WHERE dc.customer_unique_id IS NULL
       OR dc.customer_city <> sc.customer_city
       OR dc.customer_state <> sc.customer_state;
END; $$;
