/*==============================================================
  Stored Procedure: Load fact_orders incrementally
==============================================================*/
CREATE OR REPLACE PROCEDURE sp_load_fact_orders()
LANGUAGE sql
AS $$
    INSERT INTO fact_orders (
        order_id,
        customer_sk,
        order_date_sk,
        status,
        order_item_count,
        total_items_price,
        freight_value,
        review_score,
        delivery_days
    )
    SELECT
        o.order_id,
        dc.customer_sk,
        dd.date_sk,
        o.order_status,
        COUNT(oi.order_id)                         AS item_cnt,
        SUM(oi.price)                              AS items_price,
        SUM(oi.freight_value)                      AS freight,
        r.review_score,
        DATE_PART('day', o.order_delivered_customer_date - o.order_purchase_timestamp) AS delivery_days
    FROM stg_orders o
    JOIN dim_customer dc
      ON dc.customer_unique_id = o.customer_id AND dc.is_current
    JOIN dim_date dd
      ON dd.full_date = DATE(o.order_purchase_timestamp)
    JOIN stg_order_items oi USING(order_id)
    LEFT JOIN stg_order_reviews r USING(order_id)
    GROUP BY o.order_id, dc.customer_sk, dd.date_sk, o.order_status, r.review_score, delivery_days
    ON CONFLICT (order_id) DO NOTHING;
$$;
