/*==============================================================
  Load CSVs from local disk into staging tables.
  Replace <FILE_PATH> with actual path or use copy from program.
==============================================================*/
COPY stg_orders FROM '<FILE_PATH>/olist_orders_dataset.csv'
    WITH (FORMAT csv, HEADER true, DELIMITER ',');
-- Repeat for the rest of the staging tables
