-- Simple wrapper to refresh all materialized views for dashboards
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_monthly_kpi;
