# Advanced SQL Data‑Warehouse Project – Brazilian Olist E‑Commerce

This repository demonstrates **senior‑level SQL & data‑warehouse engineering** on the public Olist dataset.

## Highlights

| Layer | Skills Showcased |
|-------|------------------|
| **DDL** | Schema design, surrogate keys, partitioning, indexing |
| **ETL** | Incremental loads, SCD‑Type‑2 with stored procedures |
| **Marts** | Star schema, materialized views for BI |
| **Analytics** | RFM, CLV, cohort retention, cross‑sell, percentile stats |
| **Performance** | Query tuning, automated maintenance pipeline |
| **Testing** | SQL data‑quality assertions |

## Quick Start

1. **Create schema & tables**

   ```sql
   \i ddl/00_create_schema.sql
   \i ddl/01_create_staging_tables.sql
   \i ddl/02_create_dimension_tables.sql
   \i ddl/03_create_fact_tables.sql
   \i ddl/04_create_indexes.sql
   ```

2. **Load raw CSVs**  
   Adjust file paths in `etl/01_load_staging.sql` and run:

   ```sql
   \i etl/01_load_staging.sql
   ```

3. **Run ETL procedures**

   ```sql
   CALL sp_load_dim_customer();
   CALL sp_load_fact_orders();
   ```

4. **Refresh marts & views**

   ```sql
   \i analysis/monthly_kpi_view.sql
   \i etl/04_refresh_materialized_views.sql
   ```

## Project Structure

```
ddl/          -- schema & table DDL
etl/          -- stored procs & load scripts
analysis/     -- analytical query library
performance/  -- tuning & maintenance pipeline
tests/        -- SQL data‑quality checks
```

## License
MIT
