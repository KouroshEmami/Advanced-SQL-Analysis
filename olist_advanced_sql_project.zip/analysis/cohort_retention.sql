/*==============================================================
  Monthly Cohort Retention Analysis
==============================================================*/
WITH first_orders AS (
    SELECT
        customer_sk,
        MIN(order_date_sk) AS cohort_date_sk
    FROM fact_orders
    GROUP BY customer_sk
), cohorts AS (
    SELECT
        f.customer_sk,
        cohort_date_sk,
        f.order_date_sk,
        (order_date_sk - cohort_date_sk) / 100    AS months_since_cohort
    FROM fact_orders f
    JOIN first_orders fo ON f.customer_sk = fo.customer_sk
)
SELECT
    cohort_date_sk,
    months_since_cohort,
    COUNT(DISTINCT customer_sk) AS customers
FROM cohorts
GROUP BY cohort_date_sk, months_since_cohort
ORDER BY cohort_date_sk, months_since_cohort;
