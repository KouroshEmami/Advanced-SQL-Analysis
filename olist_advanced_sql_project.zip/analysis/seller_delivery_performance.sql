/*==============================================================
  Seller Delivery Performance – percentile stats
==============================================================*/
SELECT
    s.seller_id,
    COUNT(DISTINCT o.order_id) AS orders,
    AVG(freight_value)         AS avg_freight,
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY delivery_days) AS median_delivery_days,
    PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY delivery_days) AS p90_delivery_days
FROM fact_orders o
JOIN stg_order_items oi USING(order_id)
JOIN stg_sellers s USING(seller_id)
GROUP BY s.seller_id
ORDER BY median_delivery_days;
