/*==============================================================
  Materialized view for dashboard KPIs
==============================================================*/
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_monthly_kpi AS
SELECT
    DATE_TRUNC('month', dd.full_date) AS month,
    COUNT(DISTINCT f.order_id) AS orders,
    SUM(f.total_items_price + f.freight_value) AS revenue,
    AVG(f.total_items_price + f.freight_value) AS avg_order_value,
    COUNT(DISTINCT f.customer_sk) AS active_customers
FROM fact_orders f
JOIN dim_date dd ON dd.date_sk = f.order_date_sk
GROUP BY month;
