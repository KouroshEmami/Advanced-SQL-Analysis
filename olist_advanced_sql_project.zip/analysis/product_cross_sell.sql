/*==============================================================
  Product Pair Cross‑Sell Analysis – top pairs bought together
==============================================================*/
WITH basket AS (
    SELECT order_id,
           ARRAY_AGG(DISTINCT product_id ORDER BY product_id) AS products
    FROM stg_order_items
    GROUP BY order_id
), pairs AS (
    SELECT
        unnest(products) AS product_a,
        unnest(products[2:]) AS product_b
    FROM basket
)
SELECT
    product_a,
    product_b,
    COUNT(*) AS pair_count
FROM pairs
WHERE product_a < product_b
GROUP BY product_a, product_b
ORDER BY pair_count DESC
LIMIT 50;
