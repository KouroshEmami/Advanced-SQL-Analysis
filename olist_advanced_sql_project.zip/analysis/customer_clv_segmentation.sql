/*==============================================================
  Customer CLV & Segment Classification
==============================================================*/
WITH rfm AS (
    SELECT
        c.customer_unique_id,
        MAX(f.order_date_sk) AS last_date_sk,
        COUNT(f.order_id)    AS frequency,
        SUM(f.total_items_price + f.freight_value) AS monetary
    FROM fact_orders f
    JOIN dim_customer c ON f.customer_sk = c.customer_sk
    GROUP BY c.customer_unique_id
), rfm_scored AS (
    SELECT
        r.*,
        NTILE(5) OVER (ORDER BY DATEDIFF(day, TO_DATE(last_date_sk::text, 'YYYYMMDD'), CURRENT_DATE)) AS r_score,
        NTILE(5) OVER (ORDER BY frequency DESC) AS f_score,
        NTILE(5) OVER (ORDER BY monetary DESC)  AS m_score
    FROM rfm r
)
SELECT
    customer_unique_id,
    r_score, f_score, m_score,
    r_score + f_score + m_score AS rfm_total,
    CASE
        WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4 THEN 'Champions'
        WHEN r_score >= 4 AND f_score >= 3 THEN 'Loyal'
        WHEN r_score <= 2 AND f_score <= 2 THEN 'At Risk'
        ELSE 'Others'
    END AS segment
FROM rfm_scored;
