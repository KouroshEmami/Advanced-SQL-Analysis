/*==============================================================
  Data Quality Checks
==============================================================*/
-- 1. No duplicate primary keys
SELECT order_id, COUNT(*) FROM stg_orders GROUP BY order_id HAVING COUNT(*) > 1;

-- 2. Null checks
SELECT COUNT(*) FROM fact_orders WHERE customer_sk IS NULL;

-- 3. Referential integrity
SELECT COUNT(*) FROM fact_orders f
LEFT JOIN dim_customer c ON f.customer_sk = c.customer_sk
WHERE c.customer_sk IS NULL;
